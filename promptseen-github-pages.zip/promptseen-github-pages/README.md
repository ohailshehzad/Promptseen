# Prompt Craft Guide

A small, useful GitHub Pages resource about writing better AI image prompts. It includes a natural reference to [PromptSeen](http://promptseen.cloud/) for ready-to-use prompt ideas.

## Publish with GitHub Pages

1. Create a public GitHub repository, for example `promptseen-prompt-guide`.
2. Upload `index.html` and the `assets` folder to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then click **Save**.
6. Replace `YOUR-USERNAME` and `YOUR-REPOSITORY` in the canonical link inside `index.html` with the real GitHub Pages URL.

The page is intentionally useful and contains one contextual link instead of a list of random backlinks.
